Assignment 3 done by Group 7:

Quang Minh Le - 300165003

Mohamed Mouad Lahmam - 